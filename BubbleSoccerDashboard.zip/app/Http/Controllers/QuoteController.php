<?php

namespace App\Http\Controllers;

use App\Models\quoteModel;
use Illuminate\Http\Request;

class QuoteController extends Controller
{
    public function getQuoteData(Request $request)
    {
        $data = $request->json()->all();

        fetchAndSaveData($data);
        return redirect()->route('show.quotedata')->with('success', 'Data Saved Successfully');
    }
    public function showQuoteData()
    {
        return view('Quote.quoteData');
    }
    public function allQuoteData(Request $request)
    {
        if ($request->ajax()) {

            $totalFilteredRecord = $totalDataRecord = $draw_val = "";
            $totalDataRecord = quoteModel::count();
            $totalFilteredRecord = $totalDataRecord;

            $limit_val = $request->length;
            $start_val = $request->start;
            $columnIndex = $request->order[0]['column'];
            $quote_val = $request->columns[$columnIndex]['data'];
            $dir_val = $request->order[0]['dir'];

            if (empty($request->search['value'])) {
                $quote_data = quoteModel::offset($start_val)->limit($limit_val)->orderBy($quote_val, $dir_val)->get();
            } else {
                $search_text = $request->search['value'];

                $quote_data = quoteModel::where('mail_subject', 'LIKE', "%{$search_text}%")
                    ->orWhere('email', 'LIKE', "%{$search_text}%")
                    // ->orWhere('roles', 'LIKE', "%{$search_text}%")
                    ->offset($start_val)
                    ->limit($limit_val)
                    ->orderBy($quote_val, $dir_val)
                    ->get();

                $totalFilteredRecord = quoteModel::where('mail_subject', 'LIKE', "%{$search_text}%")
                    // ->orWhere('em', 'LIKE', "%{$search_text}%")
                    // ->orWhere('roles', 'LIKE', "%{$search_text}%")
                    ->count();
            }
            $data_val = array();
            if (!empty($quote_data)) {
                foreach ($quote_data as $quote_val) {


                    $quotenestedData['mail_subject'] = $quote_val->mail_subject;
                    $quotenestedData['telephone'] = $quote_val->telephone;
                    $quotenestedData['players'] = $quote_val->players;
                    $quotenestedData['date'] = $quote_val->date;
                    $quotenestedData['day_of_week'] = $quote_val->day_of_week;
                    $quotenestedData['time'] = $quote_val->time;
                    $quotenestedData['age_group'] = $quote_val->age_group;
                    $quotenestedData['duration'] = $quote_val->duration;

                    // $html .= '<a href="' . route('delete-user', ['id' => $quote_val->id]) . '" onclick="confirm("Do you want to delete this user ? ")"  class="btn btn-xs rounded btn-danger ml-2 px-2"> Delete </a>';
                    // $quotenestedData['action'] = $html;

                    $data_val[] = $quotenestedData;
                }
            }
            $draw_val = $request->input('draw');
            $get_json_data = array(
                "draw" => intval($draw_val),
                "recordsTotal" => intval($totalDataRecord),
                "recordsFiltered" => intval($totalFilteredRecord),
                "data" => $data_val
            );

            return response()->json($get_json_data);
        }
        return view('Quote.quoteData');
    }
}
