<?php
// In your helper file (e.g., app/helpers.php)

use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

if (!function_exists('fetchAndSaveData')) {
    function fetchAndSaveData($data)
    {

        $date = Carbon::createFromFormat('Y-m-d', $data['Date']);

        $dayOfWeek = $date->format('l');

        $adjustedData = [
            'mail_subject' => $data['Mail_subject'],
            'name' => $data['Name'],
            'players' => $data['Players'],
            'date' => $data['Date'],
            'day_of_week' => $data['DayOfWeek'] ?? $dayOfWeek,
            'time' => $data['Time'],
            'age' => $data['Age'],
            'duration' => $data['Duration'],
            'activities' => $data['Activities'] ?? ''
        ];
        $quote = \App\Models\quoteModel::create($adjustedData);
        $adjustedmetaData = [
            'quote_id' => $quote->id,
            'email_from' => $data['Email_from'] ?? '',
            'email_to' => $data['Email_to'] ?? '',
            'user_email' => $data['Email'],
            'message' => $data['Message']
        ];
        \App\Models\quoteMetaModel::create($adjustedmetaData);

        return true;

    }
}
